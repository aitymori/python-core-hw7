# python-core-hw7
installing clean_folder
